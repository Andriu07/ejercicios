package SSS0.Observation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObservationApplicationTests {

	@Test
	void contextLoads() {
	}

}

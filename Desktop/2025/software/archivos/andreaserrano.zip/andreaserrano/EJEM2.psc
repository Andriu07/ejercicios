Algoritmo EJEM2 
 	Definir num , cuadrado Como Real
	Escribir "Ingrese un n�mero ";
	leer num;
	cuadrado = num ^ 2;
	Imprimir "El n�mero es: " ,cuadrado;
FinAlgoritmo

Algoritmo EJEM3
	Definir nombre, apellido, direcci�n, g�nero Como Caracter;
	Definir edad Como Real
	Escribir "Ingrese su nombre: ";
	leer nombre;
	escribir "Ingrese su apellido: ";
	leer apellido;
	escribir "Ingrese su sirecci�n: ";
	leer direcci�n;
	escribir "Ingrese g�nero: ";
	leer genero;
	escribir "Ingrese su edad : ";
	leer edad;
	Si edad>18 Entonces
		imprimir "nombre del empleado: ", nombre;
		Imprimir "apellido del empleado: ", apellido;
		Imprimir "direcci�n del empelado: ", direcci�n;
		Imprimir "g�nero del empleado: ",genero;
		imprimir "edad del empleado: ", edad;
	SiNo
		Escribir "No permitido"
	Fin Si
	
	FinAlgoritmo

package apiPractica.Practica.deRepasopERSONAL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaDeRepasopErsonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaDeRepasopErsonalApplication.class, args);
	}

}

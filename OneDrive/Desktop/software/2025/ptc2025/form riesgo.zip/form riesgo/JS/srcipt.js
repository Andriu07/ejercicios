let reportes = JSON.parse(localStorage.getItem("reportes")) || [];
let editIndex = null;

document.addEventListener("DOMContentLoaded", () => {
  generarCodigo();
  renderTabla();
});

function generarCodigo() {
  document.getElementById("codigo").value = "RSK-" + String(Date.now()).slice(-5);
}

function mostrarAlertaGuardado() {
  const alerta = document.getElementById("alertaGuardado");
  alerta.classList.remove("d-none");
  alerta.classList.add("show");
  setTimeout(() => {
    alerta.classList.remove("show");
    alerta.classList.add("d-none");
  }, 3000);
}

function renderTabla() {
  const tbody = document.querySelector("#tablaReportes tbody");
  tbody.innerHTML = "";

  if (reportes.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No hay reportes registrados.</td></tr>`;
    return;
  }

  reportes.forEach((r, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.codigo}</td>
      <td>${r.tipo}</td>
      <td>${r.nivel}</td>
      <td>${r.probabilidad}%</td>
      <td>
        <button class="btn btn-sm btn-info me-1" onclick="verReporte(${i})"><i class="bi bi-eye"></i></button>
        <button class="btn btn-sm btn-warning me-1" onclick="editarReporte(${i})"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-danger" onclick="eliminarReporte(${i})"><i class="bi bi-trash"></i></button>
      </td>`;
    tbody.appendChild(tr);
  });
}

document.getElementById("formRiesgo").addEventListener("submit", e => {
  e.preventDefault();

  const data = {
    codigo: document.getElementById("codigo").value,
    tipo: document.getElementById("tipoRiesgo").value,
    probabilidad: document.getElementById("probabilidad").value,
    nivel: document.getElementById("nivelRiesgo").value,
    ubicacion: document.getElementById("ubicacion").value
  };

  if (editIndex !== null) {
    reportes[editIndex] = data;
    editIndex = null;
  } else {
    reportes.push(data);
  }

  localStorage.setItem("reportes", JSON.stringify(reportes));
  renderTabla();
  mostrarAlertaGuardado();
  e.target.reset();
  generarCodigo();
});

function verReporte(i) {
  const r = reportes[i];
  document.getElementById("detalleReporte").innerHTML = `
    <p><strong>Código:</strong> ${r.codigo}</p>
    <p><strong>Tipo:</strong> ${r.tipo}</p>
    <p><strong>Nivel:</strong> ${r.nivel}</p>
    <p><strong>Probabilidad:</strong> ${r.probabilidad}%</p>
    <p><strong>Ubicación:</strong> ${r.ubicacion}</p>
  `;
  new bootstrap.Modal(document.getElementById("modalVer")).show();
}

function editarReporte(i) {
  const r = reportes[i];
  editIndex = i;
  document.getElementById("codigo").value = r.codigo;
  document.getElementById("tipoRiesgo").value = r.tipo;
  document.getElementById("probabilidad").value = r.probabilidad;
  document.getElementById("nivelRiesgo").value = r.nivel;
  document.getElementById("ubicacion").value = r.ubicacion;
  document.getElementById("formRiesgo").scrollIntoView({ behavior: "smooth" });
}

function eliminarReporte(i) {
  if (confirm("¿Eliminar este reporte?")) {
    reportes.splice(i, 1);
    localStorage.setItem("reportes", JSON.stringify(reportes));
    renderTabla();
  }
}
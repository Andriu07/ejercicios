package MiApi._9.Models.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@ToString
@EqualsAndHashCode
@Getter
@Setter
public class InspectionDTO {

    private Long id;

    @NotBlank(message = "No debe de ser nulo")
    private LocalDate DateInspection;

    private String IDMember;

    @NotNull(message = "El idLocation no puede ser nulo")
    private String IDLocation;

    @NotNull(message = "EL estado de la inspeccion no puede ser nulo")
    @Min(value = 0, message = "El estado de la inspeccion debe ser 0 o 1")
    @Max(value = 1, message = "El estado de la inspeccion debe ser 0 o 1")
    private String StateInspection;
}
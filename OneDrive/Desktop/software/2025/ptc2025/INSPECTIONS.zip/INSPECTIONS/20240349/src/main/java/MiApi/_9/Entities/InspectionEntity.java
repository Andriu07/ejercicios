package MiApi._9.Entities;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@Entity
@Table(name = "TB_Inspection")
@ToString
@EqualsAndHashCode
@Getter
@Setter


@NamedStoredProcedureQuery(
        name = "UserEntity.insertInspectionByProcedure", //un nombre unico para referenciarlo en JPA
        procedureName = "PKG_ACTIONS_INSPECTION.INSERT_INSPECTION",//NOMBRE DEL  paquete.procedimiento
        parameters = {
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Inspection", type = Long.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_Date_Inspection", type = LocalDate.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Menber", type = Long.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Location" , type = String.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_State_Inspection", type = String.class),
        }
)

@NamedStoredProcedureQuery(
        name = "InspectionEntity.updateUserByProcedure", //un nombre unico para referenciarlo en JPA
        procedureName = "PKG_ACTIONS_INSPECTION.UPDATE_INSPECTION",//NOMBRE DEL  paquete.procedimiento
        parameters = {
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Inspection", type = Long.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_Date_Inspection", type = LocalDate.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Menber", type = Long.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_ID_Location" , type = String.class),
                @StoredProcedureParameter(mode = ParameterMode.IN, name = "P_State_Inspection", type = String.class),
        }
)

public class InspectionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_inspection")
    @SequenceGenerator(name = "seq_inspection", sequenceName = "seq_inspection", allocationSize = 1)
    @Column(name = "ID_Inspection")
    private Long id;

    @Column(name = "Date_Inspection")
    private LocalDate DateInspection;

    @Column(name = "ID_Member")
    private String IDMember;

    @Column(name = "ID_Location")
    private String IDLocation;

    @Column(name = "State_Inspection")
    private String StateInspection;

}

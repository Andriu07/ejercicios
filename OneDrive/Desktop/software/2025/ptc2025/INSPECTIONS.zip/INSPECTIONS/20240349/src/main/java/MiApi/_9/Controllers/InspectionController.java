package MiApi._9.Controllers;
import MiApi._9.Models.DTO.InspectionDTO;
import MiApi._9.Repositories.Inspections.InspectionRepository;
import MiApi._9.Services.Inspection.InspectionService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ApiActionInspection")
public class InspectionController {

    @Autowired
    private InspectionService acceso;
    //creamos un objeto de userservice para obtener acceso a todos sus metodos

    @GetMapping("/ObtenerInspecciones")
    public List<InspectionDTO>DataInspection(){
        return acceso.getAllInspections();
    }

    @PostMapping("/IngresarInspeccionViaSP")
    public ResponseEntity<Map<String, Object>> RegistrarInspeccionViaSP(@Valid @RequestBody InspectionDTO inspectionDTO){
        try {
            InspectionDTO respuesta = acceso.InsertarInspeccionViaSP(inspectionDTO);

            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
               "status", "succes",
               "message", "Inspeccion creada exitosamente via SP con ID generado por API",
               "data", respuesta
            ));
        } catch (Exception e) {
            System.err.println("Error al registrar inspeccion via SP: " + e.getMessage());
            e.printStackTrace();return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "status", "succes",
                    "message", "Inspeccion creada exitosamente via SP con ID generado por API",
                    "data", e.getMessage()
            ));

        }
    }

     @PutMapping("ActualizarInspeccionViaSP/{id}")
     public ResponseEntity<Map<String, Object>> ActualizarInspeccionViaSP(@PathVariable Long id, @Valid @RequestBody InspectionDTO inspectionDTO) {
         try {
             if (inspectionDTO.getId() != null && !inspectionDTO.getId().equals(id)) {
                 return ResponseEntity.badRequest().body(Map.of(
                         "status", "error",
                         "message", "El id en la URL y el ID en el cuerpo no coinciden"
                 ));

             }

             inspectionDTO.setId(id);

             InspectionDTO respuesta = acceso.ActualizarInspeccionViaSP(inspectionDTO, id);
             return ResponseEntity.ok().body(Map.of(
                     "status", "succes",
                     "message", "Inspeccion actualizada exitosamente via SP",
                     "data", respuesta

             ));
         } catch (Exception e) {
             System.err.println("Error al registrar inspeccion via SP: " + e.getMessage());
             e.printStackTrace();
             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                     "status", "error",
                     "message", "Error interno del servidor al registrar inspeccion via SP",
                     "data", e.getMessage()
             ));
         }
     }


    @DeleteMapping("/EliminarInspeccion/{id}")
    public ResponseEntity<Void> deleteInspection(@PathVariable Long id) {
        InspectionService.deleteInspection(id);
        return ResponseEntity.noContent().build();
    }
}



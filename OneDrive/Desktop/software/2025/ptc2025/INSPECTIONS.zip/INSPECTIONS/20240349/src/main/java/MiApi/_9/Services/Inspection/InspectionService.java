package MiApi._9.Services.Inspection;

import MiApi._9.Entities.InspectionEntity;
import MiApi._9.Models.DTO.InspectionDTO;
import MiApi._9.Repositories.Inspections.InspectionRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.StoredProcedureQuery;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InspectionService {

    @Autowired
    InspectionRepository repo;

    @Autowired
    private EntityManager entityManager;


    //metodo para obtner inspeccion
    public List<InspectionDTO> getAllInspections() {
        //obtnemos todos las inspecciones "crudas" de la  base de datos
        List<InspectionEntity> inspection = repo.findAll();
        //Transformamos cada inspeccion "crudo " en una opcion mas limpia (InspectionDTO)
        return inspection.stream()
                .map(this::convertirAInspectionDTO)
                .collect(Collectors.toList());
    }

    //METODO CONVERTIR A inspeccion DTO
    private InspectionDTO convertirAInspectionDTO(InspectionEntity inspection) {
        InspectionDTO dto = new InspectionDTO();
        dto.setId(inspection.getId());
        dto.setDateInspection(inspection.getDateInspection());
        dto.setIDMember(inspection.getIDMember());
        dto.setIDLocation(inspection.getIDLocation());
        dto.setStateInspection(inspection.getStateInspection());
        return dto;
    }


    @Transactional
    public InspectionDTO InsertarInspeccionViaSP(InspectionDTO InspectionOFDTO){
        if (InspectionOFDTO == null || InspectionOFDTO.getIDMember() == null || InspectionOFDTO.getIDMember().trim().isEmpty() ||
                InspectionOFDTO.getIDLocation() == null || InspectionOFDTO.getIDLocation().trim().isEmpty() ||
                InspectionOFDTO.getDateInspection() == null || InspectionOFDTO.getStateInspection() == null) {
            throw new IllegalArgumentException("Id de Miembro, Id de Ubicacion , Fecha de Inspeccion y Estado de Inspeccion no pueden ser nulos o vacíos.");
    }
        try{
            BigDecimal sequenceValue = (BigDecimal) entityManager.createNativeQuery("SELECT seq_inspection");
                    //Convertir el BigDecimal a Long
            Long generatedId = sequenceValue.longValue();

            //asignar el ID generado al DTO
            InspectionOFDTO.setId(generatedId);

            //crear y configurar la llamada del procedimiento almacenado
            StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("InspectionEntity.insertInspectionByProcedure");

            query.setParameter("P_ID_Inspection", InspectionOFDTO.getId());
            query.setParameter("P_Date_Inspection", InspectionOFDTO.getDateInspection());
            query.setParameter("P_ID_Member", InspectionOFDTO.getIDMember());
            query.setParameter("P_ID_Location", InspectionOFDTO.getIDLocation());
            query.setParameter("P_State_Inspection", InspectionOFDTO.getStateInspection());
            query.execute();
            return InspectionOFDTO;
        }catch (Exception e){
            System.err.println("Error al insertar Inspecion via SP" + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Error al registrar inspeccion via procedimiento almacenado" + e);
        }
    }

    @Transactional
    public InspectionDTO ActualizarInspeccionViaSP(InspectionDTO inspectionDTO, Long id){
        if (id == null || inspectionDTO == null || !id.equals(inspectionDTO.getId())){
            throw new IllegalArgumentException("ID en la URL y en el cuerpo deban coincidir y no ser nulos");
        }
        if(inspectionDTO.getIDLocation() == null || inspectionDTO.getIDLocation().trim().isEmpty()||
                inspectionDTO.getIDMember() == null || inspectionDTO.getIDMember().trim().isEmpty()|| inspectionDTO.getId() == null ){
            throw new IllegalArgumentException("ID de ubicacion , ID de mienbro y  ID  de Inspeccion no pueden estar nulos o vacios");
        }
        try{
            StoredProcedureQuery query = entityManager.createNamedStoredProcedureQuery("InspectionEntity.updateUserByProcedure");

            query.setParameter("P_ID_Inspection", inspectionDTO.getId());
            query.setParameter("P_ID_Menber", inspectionDTO.getIDMember());
            query.setParameter("P_ID_Location", inspectionDTO.getIDLocation());

            query.execute();

            return inspectionDTO;
        }catch (Exception e){
            System.err.println("Error al insertar inspeccion via SP" + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Error al registrar inspeccion via procedimiento almacenado" + e);
        }
    }


    @Transactional
    public static InspectionDTO deleteInspection(Long id) {
            if (!repo.existsById(id)) {
                throw new RuntimeException("No se encontró inspeccion con ID: " + id);
            }
            repo.deleteById(id);
    }

}



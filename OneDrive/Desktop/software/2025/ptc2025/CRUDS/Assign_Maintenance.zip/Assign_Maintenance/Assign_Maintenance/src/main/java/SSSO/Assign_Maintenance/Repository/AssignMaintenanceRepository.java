package SSSO.Assign_Maintenance.Repository;

import SSSO.Assign_Maintenance.Entities.AssignMaintenanceEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AssignMaintenanceRepository  extends JpaRepository<AssignMaintenanceEntity, Long> {
}

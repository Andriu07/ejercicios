package SSSO.Assign_Maintenance.Models.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@EqualsAndHashCode
@Getter
@Setter
@ToString

public class AssignMaintenanceDTO {

    private Long id_assign_maintenance;

    @NotNull
    private Long id_type_maintenance;

    @NotBlank
    private String id_maintenance;
}

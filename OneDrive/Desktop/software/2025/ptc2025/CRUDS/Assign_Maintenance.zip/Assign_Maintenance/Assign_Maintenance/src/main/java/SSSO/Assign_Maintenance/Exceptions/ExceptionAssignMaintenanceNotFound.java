package SSSO.Assign_Maintenance.Exceptions;

public class ExceptionAssignMaintenanceNotFound extends RuntimeException {
    public ExceptionAssignMaintenanceNotFound(String message) {
        super(message);
    }
}

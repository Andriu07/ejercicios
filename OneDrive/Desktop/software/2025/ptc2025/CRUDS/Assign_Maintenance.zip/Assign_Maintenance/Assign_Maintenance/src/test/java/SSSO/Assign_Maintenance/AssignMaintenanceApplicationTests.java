package SSSO.Assign_Maintenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignMaintenanceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package SSSO.Assign_Maintenance.Controller;

import SSSO.Assign_Maintenance.Exceptions.ExceptionAssignMaintenanceNotFound;
import SSSO.Assign_Maintenance.Exceptions.ExceptionDatosDuplicados;
import SSSO.Assign_Maintenance.Models.DTO.AssignMaintenanceDTO;
import SSSO.Assign_Maintenance.Service.AssignMaintenanceService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/apiAssignMaintenance")
public class AssignMaintenanceController {

    @Autowired
    AssignMaintenanceService Service;


    @GetMapping("/consultarDatos")
    public List<AssignMaintenanceDTO> ObtenerDatos() {
        return Service.ObtenerAsignacionesdeMantenimiento();
    }


    //inserccion de datos
    @PostMapping("/registrarDatos")
    public ResponseEntity<?> nuevaAsignaciondeMantenimineto(@Valid @RequestBody AssignMaintenanceDTO json, HttpServletRequest request) {
        try {
            AssignMaintenanceDTO respuesta = Service.InsertarDatos(json);
            if (respuesta == null) {
                return ResponseEntity.badRequest().body(Map.of(
                        "status", "inserccion fallida",
                        "errorType", "Validation_error",
                        "message", "Los datos no pudieron ser registrados"
                ));
            }
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "status", "succes",
                    "data", respuesta
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "status", "error",
                    "message", "error no controlado al registrar asignacion de mantenimiento",
                    "detail", e.getMessage()
            ));
        }
    }

    @PutMapping("/editarAsignacionDeMantenimineto/{id_assign_maintenance}")//Url
    public ResponseEntity<?> modificarAsignaciondeMantenimineto(@PathVariable Long id_assign_maintenance, @Valid @RequestBody AssignMaintenanceDTO json, BindingResult bindingResult) {
        //verificar si hay errores de validacion{e}: campos vacios,formatos incorrectos
        if (bindingResult.hasErrors()) {
            Map<String, String> errores = new HashMap<>();
            bindingResult.getFieldErrors().forEach(error ->
                    errores.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        try {
            //intetar actualizar  llamando al servicio y guaradar el resultado en un DTO
            AssignMaintenanceDTO dto = Service.actualizarAsignaciondeMantenimiento(id_assign_maintenance, json);
            //SI sale bien laoperacion retornar HTTP 200 (ok) con el DTO actualizado
            return ResponseEntity.ok(dto);
        } catch (ExceptionAssignMaintenanceNotFound e) {
            //si  no existe, retornar HTTP 400 (not found)
            return ResponseEntity.notFound().build();
        } catch (ExceptionDatosDuplicados e) {
            //si hay datos duplicados retornar HTTP 409 (CONFLICT)
            return ResponseEntity.status(HttpStatus.CONFLICT).body(
                    Map.of(
                            "Error", "Datos duplicados",
                            "Campo", e.getCampoDuplicado()
                    )
            );
        }
    }

    @DeleteMapping("/eliminarAsignaciondeMantenimiento/{id_assign_maintenance}")
    public ResponseEntity<?> eliminarAsignaciondeMantenimiento(@PathVariable Long id_assign_maintenance) {
        try {
            if (!Service.removerAsignaciondeMantenimiento(id_assign_maintenance)) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .header("mensaje de error", "Asignacion de mantenimineto no encontrada")
                        .body(Map.of(
                                "Error", "NOT FOUND",
                                "Message", "La asignacion de mantenimineto  no fue encontrado",
                                "timestamp", Instant.now().toString()
                        ));
            }
            return ResponseEntity.ok().body(Map.of(
                    "Status", "Proceso completado",
                    "message", "Asignacion de mantenimineto elminada exitosamente"
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of(
                    "Status", "Error",
                    "Message", "Error al eliminar asignacion de mantenimiento",
                    "detail", e.getMessage()
            ));
        }
    }
}
package SSSO.Assign_Maintenance.Exceptions;

import lombok.Getter;

public class ExceptionDatosDuplicados extends RuntimeException {

    public ExceptionDatosDuplicados(String message) {
        super(message);
    }

    @Getter
    private String campoDuplicado;

    public ExceptionDatosDuplicados(String message ,String campoDuplicado){
        super( message);
        this.campoDuplicado = campoDuplicado;
    }

}

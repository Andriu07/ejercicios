package SSSO.Assign_Maintenance.Service;

import SSSO.Assign_Maintenance.Entities.AssignMaintenanceEntity;
import SSSO.Assign_Maintenance.Exceptions.ExceptionAssignMaintenanceNotFound;
import SSSO.Assign_Maintenance.Exceptions.ExceptionAssignMaintenanceNoyRegister;
import SSSO.Assign_Maintenance.Models.DTO.AssignMaintenanceDTO;
import SSSO.Assign_Maintenance.Repository.AssignMaintenanceRepository;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class AssignMaintenanceService {

    @Autowired
    AssignMaintenanceRepository repository;

    public List<AssignMaintenanceDTO> ObtenerAsignacionesdeMantenimiento() {
        List<AssignMaintenanceEntity> lista = repository.findAll();
        return lista.stream()
                .map(this::convertirADTO)
                .collect(Collectors.toList());
    }


    private AssignMaintenanceDTO convertirADTO(AssignMaintenanceEntity assignMaintenanceEntity) {
        //creando objeto a retornar
        AssignMaintenanceDTO dto = new AssignMaintenanceDTO();
        dto.setId_assign_maintenance(assignMaintenanceEntity.getId_assign_maintenance());
        dto.setId_type_maintenance(assignMaintenanceEntity.getId_type_maintenance());
        dto.setId_maintenance(assignMaintenanceEntity.getId_maintenance());
        return dto;
    }

    public AssignMaintenanceDTO InsertarDatos(AssignMaintenanceDTO data) {
        if (data == null || data.getId_maintenance() == null || data.getId_type_maintenance() == null ) {
            throw new IllegalArgumentException("Asignacion de mantenimineto, Id Mantenimiento y Id tipo de Mantenimiento no pueden ser nulos");
        }
        try {
            AssignMaintenanceEntity entity = ConvertirAEntity(data);
            AssignMaintenanceEntity asignaciondeMantenimientoguardada = repository.save(entity);
            return convertirADTO(asignaciondeMantenimientoguardada);
        } catch (Exception e) {
            log.error("Error al registrar el usuario: " + e.getMessage());
            throw new ExceptionAssignMaintenanceNoyRegister("Error al registrar asignacion de mantenimiento");
        }
    }

    private AssignMaintenanceEntity ConvertirAEntity(AssignMaintenanceDTO data) {
        AssignMaintenanceEntity entity = new AssignMaintenanceEntity();
        entity.setId_assign_maintenance(data.getId_assign_maintenance());
        entity.setId_type_maintenance(data.getId_type_maintenance());
        entity.setId_maintenance(data.getId_maintenance());
        return entity;
    }


    public AssignMaintenanceDTO actualizarAsignaciondeMantenimiento(Long id_assign_maintenance, @Valid AssignMaintenanceDTO json) {
        //varificar la existencia
        AssignMaintenanceEntity existente = repository.findById(id_assign_maintenance).orElseThrow(() -> new ExceptionAssignMaintenanceNotFound("Asignacion de mantenimiento no encontrada"));
        //convertir los datos dto a entity
        existente.setId_assign_maintenance(json.getId_assign_maintenance());
        existente.setId_type_maintenance(json.getId_type_maintenance());
        existente.setId_maintenance(json.getId_maintenance());
        //guardar los nuevos valores
        AssignMaintenanceEntity asignaciondeMantenimientoActualizada = repository.save(existente);
        //convertir los datos de entity a DTO
        return convertirADTO(asignaciondeMantenimientoActualizada);
    }


    public boolean removerAsignaciondeMantenimiento(Long id_assign_maintenance) {
        try {
            AssignMaintenanceEntity existente = repository.findById(id_assign_maintenance).orElse(null);
            if (existente != null) {
                repository.deleteById(id_assign_maintenance);
                return true;
            } else {
                return false;
            }
        } catch (EmptyResultDataAccessException e) {
            throw new EmptyResultDataAccessException("No se encontro assignacionde mantenimineto con el id  " + id_assign_maintenance + "para eliminar.", 1);
        }
    }
}

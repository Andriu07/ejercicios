package SSSO.Assign_Maintenance.Exceptions;

public class ExceptionAssignMaintenanceNoyRegister extends RuntimeException {
    public ExceptionAssignMaintenanceNoyRegister(String message) {
        super(message);
    }
}

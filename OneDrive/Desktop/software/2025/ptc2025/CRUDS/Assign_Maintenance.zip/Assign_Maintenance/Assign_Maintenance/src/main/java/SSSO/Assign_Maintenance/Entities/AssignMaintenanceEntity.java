package SSSO.Assign_Maintenance.Entities;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TB_ASSIGN_MAINTENANCE")
@EqualsAndHashCode
@Getter
@Setter
@ToString
public class AssignMaintenanceEntity {

    @Id
    @Column(name = "ID_ASSIGN_MAINTENANCE")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_assign_maintenance")
    @SequenceGenerator(name = "seq_assign_maintenance", sequenceName = "seq_assign_maintenance", allocationSize = 1)
    private Long id_assign_maintenance;

    @Column(name = "ID_TYPE_MAINTENANCE")
    private Long id_type_maintenance;

    @Column(name = "ID_MAINTENANCE")
    private String id_maintenance;
}

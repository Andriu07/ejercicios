package SSSO.Assign_Maintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignMaintenanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignMaintenanceApplication.class, args);
	}

}
